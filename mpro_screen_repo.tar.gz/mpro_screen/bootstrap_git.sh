#!/usr/bin/env bash
# One-shot: turn this folder into a git repo and push it to GitHub.
# Usage:
#   ./bootstrap_git.sh git@github.com:USERNAME/mpro_screen.git
# or with an HTTPS remote:
#   ./bootstrap_git.sh https://github.com/USERNAME/mpro_screen.git
set -euo pipefail

REMOTE="${1:-}"
if [[ -z "$REMOTE" ]]; then
  echo "usage: $0 <git-remote-url>"
  echo "  create an empty repo on github.com first (no README/license),"
  echo "  then pass its clone URL here."
  exit 1
fi

git init -b main
git add -A
git commit -m "mpro_screen: reusable ColabFold binder-design screening pipeline"
git remote add origin "$REMOTE"
git push -u origin main
echo "Pushed to $REMOTE"
